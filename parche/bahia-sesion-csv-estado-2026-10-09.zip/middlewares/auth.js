const db = require('../config/db');
const { hashToken } = require('../config/tokens');

/**
 * Destino inicial de cada rol tras un acceso válido.
 * El capitán es personal de servicio con rol elevado: comparte el circuito
 * del dependiente (dashboard -> POS -> precuenta -> cobro) y NO el panel
 * administrativo. Los roles sin panel asignado devuelven null (se les
 * cierra la sesión con un aviso en lugar de dejarlos en un bucle login).
 */
const DESTINOS_POR_ROL = {
    superadministrador: '/admin/dashboard',
    administrador: '/admin/dashboard',
    dependiente: '/dependiente/dashboard',
    capitan: '/dependiente/dashboard',
    bartender: '/monitor/bar',
    'jefe-cocina': '/monitor/cocina',
    cocinero: '/monitor/cocina',
    'ayudante-cocina': '/monitor/cocina',
    luncher: '/monitor/cocina',
    porcionador: '/monitor/cocina',
    cajero: '/admin/pedidos',
    economico: '/admin/cierre-dia',
    almacenero: '/admin/almacenes'
};

function destinoPorRol(rol) {
    if (!rol) return null;
    return DESTINOS_POR_ROL[String(rol).toLowerCase()] || null;
}

module.exports = {
    destinoPorRol,
    DESTINOS_POR_ROL,
    // 1. Tu guardián existente de autenticación por sesión
    ensureAuthenticated: function(req, res, next) {
        if (req.isAuthenticated()) {
            return next();
        }
        req.flash('error_msg', 'Por favor, inicia sesión para acceder a esta sección.');
        res.redirect('/login');
    },

    // 2. NUEVO: Guardián de autorización basado en Roles
    checkRole: function(rolesPermitidos) {
        return (req, res, next) => {
            // Verificamos si hay un usuario autenticado y si su rol está en la lista permitida
            if (req.user && rolesPermitidos.includes(req.user.rol)) {
                return next(); // El usuario tiene el rol correcto, continúa a la ruta
            }
            
            // Un usuario autenticado con otro rol no debe caer al formulario
            // de acceso (antes el capitán terminaba en un bucle /login):
            // se le devuelve a SU panel con un aviso. Solo los anónimos
            // (o roles sin panel asignado) van al login/logout.
            if (req.user && req.user.rol) {
                const destino = destinoPorRol(req.user.rol);
                req.flash('error_msg', 'No tienes permisos autorizados para acceder a esta sección.');
                if (destino && req.path !== destino && req.originalUrl !== destino) {
                    return res.redirect(destino);
                }
                if (!destino) {
                    return res.redirect('/logout');
                }
            }
            req.flash('error_msg', 'No tienes permisos autorizados para acceder a esta sección.');
            res.redirect('/login'); // Para evitar redirecciones infinitas
        };
    },

    // 3. Comprueba la funcionalidad de la funcion recordar usuario durante el login
    checkRememberMe: async function(req, res, next) {
        // Si el usuario ya está autenticado en la sesión actual, continuamos normalmente
        if (req.isAuthenticated()) {
            return next();
        }

        // Comprobamos si existe la cookie firmada 'remember_me'
        const cookieToken = req.signedCookies.remember_me;

        if (cookieToken) {
            try {
                // Buscar el token en la base de datos y verificar que no haya expirado
                // Reemplaza 'db.query' por el formato exacto que uses (promesas, pool, etc.)
                // En la base solo hay huellas: se compara la huella de la
                // cookie, nunca el valor en claro.
                const [rows] = await db.query(
                    `SELECT usuario_id FROM usuarios_tokens 
                     WHERE token = ? AND expira_en > NOW() 
                     LIMIT 1`, 
                    [hashToken(cookieToken)]
                );

                if (!rows || rows.length === 0) {
                    // Token inexistente o caducado: se retira la cookie para no
                    // repetir la consulta en cada petición del navegador.
                    res.clearCookie('remember_me', { path: '/' });
                    // Se espera al borrado: disparado sin await, la limpieza puede
                    // quedar a medias cuando la petición ya ha terminado.
                    try {
                        await db.query('DELETE FROM usuarios_tokens WHERE expira_en <= NOW()');
                    } catch (_) { /* la limpieza nunca debe bloquear el acceso */ }
                }

                if (rows && rows.length > 0) {
                    const usuarioId = rows[0].usuario_id;

                    // Buscar los datos completos del usuario para loguearlo en Passport
                    const [userRows] = await db.query(
                        'SELECT * FROM usuarios WHERE id = ? LIMIT 1', 
                        [usuarioId]
                    );

                    if (userRows && userRows.length > 0) {
                        const user = userRows[0];

                        // Una cuenta desactivada no debe reactivarse sola por
                        // tener una cookie antigua en el navegador.
                        if (user.activo === 0 || user.activo === false) {
                            await db.query('DELETE FROM usuarios_tokens WHERE usuario_id = ?', [user.id]);
                            res.clearCookie('remember_me', { path: '/' });
                            return next();
                        }

                        // Iniciar la sesión de Passport de manera automática
                        req.logIn(user, (err) => {
                            if (err) return next(err);

                            // Passport deja el usuario en req.user, pero buena
                            // parte de la aplicación lee `req.session.user`
                            // (la pantalla de acceso, las variables globales de
                            // las vistas, varios controladores). Sin esto la
                            // sesión quedaba a medias: las rutas protegidas
                            // funcionaban, pero /login seguía mostrando el
                            // formulario y el usuario concluía que
                            // "Recuérdame" no servía para nada.
                            req.session.user = {
                                id: user.id,
                                nombre: user.nombre,
                                apellidos: user.apellidos,
                                email: user.email || null,
                                usuario: user.usuario,
                                rol: user.rol,
                                foto: user.foto || null
                            };
                            return next();
                        });
                        return; // Evita que ejecute el next() del final de la función antes de tiempo
                    }
                }
            } catch (error) {
                console.error('Error en la validación automática del token:', error);
                // Si hay un error de DB, limpiamos la cookie dañada y continuamos al login normal
                res.clearCookie('remember_me');
            }
        }

        next();
    },

    // Sesión deslizante: cada operación del usuario autenticado renueva su
    // vigencia, para no expulsarlo en caliente a mitad del trabajo. Solo se
    // toca la sesión si pasaron más de 5 minutos desde el último desliz
    // (así no se escribe en la BD en cada petición): al modificarla,
    // express-session la guarda, extiende expira_en y reemite la cookie con
    // su maxAge renovado.
    deslizarSesion: function(req, res, next) {
        try {
            if (req && req.session && typeof req.isAuthenticated === 'function' && req.isAuthenticated()) {
                const ahora = Date.now();
                const ultima = Number(req.session.ultima_actividad) || 0;
                if (ahora - ultima > 5 * 60 * 1000) {
                    req.session.ultima_actividad = ahora;
                }
            }
        } catch (_) { /* el desliz nunca debe bloquear la petición */ }
        next();
    }
};