const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const tableController = require('../controllers/tableController');
const menuController = require('../controllers/menuController');
const dashboardController = require('../controllers/dashboardController');
const dashboardDependienteController = require('../controllers/dashboardDependienteController');
const path = require('path');
const multer = require('multer');
const { menuValidationRules, mesaValidationRules, handleValidationErrors } = require('../middlewares/validator');
const { asegurarTurnoActivo } = require('../middlewares/verificarTurno');

// Configuración de almacenamiento de Multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/'); // Asegúrate de que esta carpeta exista en tu proyecto
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

// Importamos ambos guardianes
const { ensureAuthenticated, checkRole } = require('../middlewares/auth');

// URL Real: GET http://localhost:3000/admin/dashboard
router.get('/dashboard', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), dashboardController.index);

// POS MESERO — Visualización del salón/POS de un mesero (solo administración)
router.get('/pos-mesero', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), dashboardDependienteController.viewSelectorMesero);
router.get('/pos-mesero/ver', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), dashboardDependienteController.viewDashboardMesero);
// Endpoint API para polling periódico del Dashboard
router.get('/api/dashboard/metrics', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), dashboardController.apiMetrics);

// ==========================================
// MÓDULO: GESTIÓN DE MESAS
// ==========================================

// Vista principal de las mesas
router.get('/mesas', ensureAuthenticated, checkRole(['superadministrador', 'administrador', 'dependiente']), tableController.listTables);

// Acciones CRUD de mesas (Restringido solo a administradores)
router.post('/mesas/crear', mesaValidationRules.create, handleValidationErrors, ensureAuthenticated, checkRole(['superadministrador', 'administrador']), tableController.createTable);
router.post('/mesas/editar/:id', mesaValidationRules.update, handleValidationErrors, ensureAuthenticated, checkRole(['superadministrador', 'administrador']), tableController.updateTable);
router.delete('/mesas/eliminar/:id', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), tableController.deleteTable);

// ==========================================
// MÓDULO: GESTIÓN DE PLATILLOS / MENÚ
// ==========================================

// Vista principal del menú (Listar todos los platillos)
router.get('/menu', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.listMenu);
router.get('/menu/exportar', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.exportarMenu);
router.get('/menu/exportar/pdf', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.exportarMenuPDF);

// Acciones CRUD de Platillos
router.post('/menu/crear', upload.single('foto'), menuValidationRules.create, handleValidationErrors, ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.createDish);
router.post('/menu/editar/:id', upload.single('foto'), menuValidationRules.update, handleValidationErrors, ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.updateDish);
router.post('/menu/eliminar/:id', menuValidationRules.delete, handleValidationErrors, ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.deleteDish);

// ==========================================
// MÓDULO: PLATILLOS DEL DÍA (TURNO ACTIVO)
// ==========================================
router.post('/menu/platillo-dia/crear', upload.single('foto'), ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.createPlatilloDia);
router.post('/menu/platillo-dia/reutilizar/:id', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.reutilizarPlatilloDia);
router.delete('/menu/platillo-dia/eliminar/:id', ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.deletePlatilloDia);
router.post('/menu/platillo-dia/editar/:id', upload.single('foto'), ensureAuthenticated, checkRole(['superadministrador', 'administrador']), menuController.updatePlatilloDia);

// Nueva acción para guardar la distribución por lote (Permite Capitán)
router.post('/mesas/distribucion', ensureAuthenticated, checkRole(['superadministrador', 'administrador', 'capitan']), asegurarTurnoActivo, tableController.saveDistribution);

module.exports = router;